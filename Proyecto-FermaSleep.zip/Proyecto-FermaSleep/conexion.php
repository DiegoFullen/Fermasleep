<?php

$server = "127.0.0.1"; //ruta de la direccion IP
$database = "fermasleep";
$username = "root";
$password = "";

$con = mysqli_connect($server, $username, $password, $database);

if(!$con){
    echo "Error en la conexion";
}else{
    echo "Conexion exitosa";
}

?>