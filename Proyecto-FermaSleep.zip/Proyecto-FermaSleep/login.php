<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
</head>
<?php
if ($_POST) {
	$basededatos="fermasleep";
    
    $Correo = $_POST["correo"];
    $Password = $_POST["pwd"];

    $conexion = mysqli_connect("localhost","root","")
		or die ("Fallo en la conexion");

		mysqli_select_db($conexion,$basededatos)
		or die ("Error en la seleccion de la base de datos");

		$consulta = mysqli_query($conexion, "SELECT * FROM `usuarios` WHERE `correo` = '$Correo' AND `contrasena` = '$Password'");

		if ((mysqli_num_rows($consulta)) > 0) {
			session_start();

			while($row = mysqli_fetch_array($consulta)){
				$tipo = $row['tipo'];
				$_SESSION['usuario'] = $row['nombre'];
				$_SESSION['tipo'] = $row['tipo'];
			}
			if($tipo == "Admin"){
				echo '<META HTTP-EQUIV="REFRESH" CONTENT="1; URL=./Admin/menuAdmin.php">';
			}else{
				echo '<META HTTP-EQUIV="REFRESH" CONTENT="1; URL=./Clientes/menuClientes.php">';
			}
			
		}else {
			echo "Error en la consulta";
			mysqli_close($conexion);
		}
	
}else{
	echo "No se esta ejecutando por POST";
}
?>
</html>