<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/styles.css">
    <title>FERMASLEEP</title>
</head>
<body>
    <section class="top-section">
        <div>
            <img src="../images/logo-mini_1.3.png" alt="logo.FERMASLEEP" class="logo">
        </div>
        <div class="semiNav2">
            <div class="bloqueNav2">
                <a href="Carrito.php" style="width: 100%; display: flex; justify-content: center;"><img src="../images/iconos/card/carrito.png" alt="carrito"  width="30" height="30" class="icon-banner"></a>
            </div>
        </div>
    </section>
    <nav class="navegador">
        <ul class="semiNav">
            <li class="bloqueNav">
                <a href="menuClientes.php" class="txtNav"><img src="../images/iconos/banner/home.png" alt=""  width="20" height="20" class="icon-banner">Home</a>
            </li>
            <li class="bloqueNav">
                <!-- 
                    <ul style="margin: 0%;">
                    <li><a href="">Agregar</a></li>
                    <li><a href="#">Eliminar</a></li>
                    <li><a href="#">Submenu3</a></li>
                    </ul>
                 -->
                
                <a href="Productos.php" class="txtNav">
                <img src="../images/iconos/banner/shop.png" alt="" width="20" height="20" class="icon-banner">Productos</a>
                    
            </li>
            <li class="bloqueNav">
                <a href="../Ubicacion.html" class="txtNav"><img src="../images/iconos/banner/ubicacion.png" alt="" width="20" height="20" class="icon-banner">Ubicacion</a>
            </li>
        </ul>
    </nav>
    <section class="seccion1">
        <div class="banner-cover">
            <div class="banner-container">
                <h1 class="title-cover">Fermasleep</h1>
            </div>
        </div>
    </section>      
    <section class="seccion2">
        <table class="tablaProductos">
            <tr class="trProductos">
                <?php
                    session_start();

		            $conexion = mysqli_connect("localhost","root","")
		            or die ("Fallo en la conexion");

		            mysqli_select_db($conexion, "fermasleep")
		            or die ("Error en la seleccion de la base de datos");

		            $Resultado = mysqli_query($conexion,"SELECT * FROM `productos` WHERE `id` BETWEEN 4 AND 6;");

		                while ($row = mysqli_fetch_array($Resultado)) {
                            echo '
                            <td class="tdProductos">
                                <div class="elementos">
                                    <div class="card-top">';
                                    if($row['descuento'] != 0){
                                        echo '<h3 class="card-top-text">PROMOCION</h3>';
                                        echo '<h3 class="card-top-text">'.$row['descuento'].' %</h3>';
                                    }else{
                                        echo '<h3 class="card-top-text"> </h3>';
                                    }
                                    echo '
                                    </div>
                                    <img src="../images/productos/pijama'.$row['id'].'.jpg" alt="logo.FERMASLEEP" class="card">
                                    <div class="details">
                                        <h4 style="color: rgb(50, 50, 50); font-weight: bold; font-size: 23px;">'.$row['nombre'].'</h4>
                                        <div style="width: 100%; height: auto;">
                                            <p class="parrafos">'.$row['descripcion'].'</p>
                                        </div>
                                        <div class="card-price">
                                            <h5>Precio: </h5>
                                            <h5 class="price">$'.$row['precio']-(($row['descuento']*$row['precio'])/100).'</h5>';
                                            if($row['descuento'] != 0){
                                                echo '<h5 class="discount-price">$'.$row['precio'].'</h5>';
                                            }
                                            echo '
                                        </div>
                                        <div class="card-price">
                                            <h5>Talla: </h5>
                                            <h5>'.$row['talla'].'</h5>
                                        </div>
                                        <div class="card-price">
                                            <h5>Color: </h5>
                                            <div class="cuadroColor" style="background-color: #'.$row['color'].';"></div>
                                        </div>
                                    </div>
                                    <div class="cardDetails">
                                        <a href="../agregarCarrito.php?id='.$row['id'].'"><img src="../images/iconos/card/carrito.png" alt="carrito" class="iconCard" width="40" height="40"></a>
                                        <a href="#"><img src="../images/iconos/card/fav.png" alt="favorite" class="iconCard" width="40" height="40"></a>
                                        <a href="Productos.php"><img src="../images/iconos/card/ver.png" alt="see" class="iconCard" width="40" height="40"></a>
                                    </div>
                                </div>
                            </td>';
                            if(($row['id']%3) == 0){
                                echo '<tr>';                                                                                                                                         
                            }
		                }	
		            mysqli_close($conexion);
		        ?>
            </tr>
        </table>
        <table style="margin-top: 10%;">
            <tr>
                <td class="interSec1">
                    <h4 class="titleTexto">Misión</h4>
                </td>
                <td class="interSec1">
                    <h4 class="titleTexto">Visión</h4>
                </td>
            </tr>
            <tr>
                <td class="interSec1">
                    <h4 class="secTexto">
                        Hacer productos de calidad que brinden comodidad y confort,
                        con materiales de calidad a precios accesibles
                    </h4>
                </td>
                <td class="interSec1">
                    <h4 class="secTexto">
                        Ser un negocio referente a las ventas de pijamas 
                        cuya principal prioridad es proporcionar
                        buena calidad de productos a un precio 
                        accesible, contemplando un crecimiento nacional
                    </h4>
                </td>
            </tr>
        </table>
    </section>
</body>
<footer>
    <div class="footer-container">
        <div class="footer-socials">
            <a class="footer-solcials-link" href="#"><img src="../images/iconos/social/facebook.png" alt="facebook" class="icon"></a>
            <a class="footer-solcials-link" href="#"><img src="../images/iconos/social/instagram.png" alt="instagram" class="icon"></a>
            <a class="footer-solcials-link" href="#"><img src="../images/iconos/social/twitter.png" alt="twitter" class="icon"></a>
            <a class="footer-solcials-link" href="#"><img src="../images/iconos/social/pinterest.png" alt="pinterest" class="icon"></a>
        </div>
    </div>
</footer>
</html>