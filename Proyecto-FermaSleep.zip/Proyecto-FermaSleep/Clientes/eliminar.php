<!DOCTYPE html>
<html lang="es">
<head>
	<title>Eliminar</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="stylesheet" type="text/css" href="./styles.css">
</head>

<body>
<section>
	<?php
        isset($_GET['id']);
        $id = $_GET['id'];
	
		$NombreArchivo = "Pedidos.json";
		$archivo = file_get_contents($NombreArchivo);
		$productos = json_decode($archivo);

		$contador = 0;
		foreach ($productos as $producto) {
			if($id == $producto->{'id'}){
                unset($productos[$contador]);
			}
			$contador++;
		}
		
		$productos = array_values($productos);
		
		$json_string = json_encode($productos);
        file_put_contents($NombreArchivo, $json_string);
        echo '<META HTTP-EQUIV="REFRESH" CONTENT="0; URL=Carrito.php">';
		
	?>
</section>
</body>
</html>