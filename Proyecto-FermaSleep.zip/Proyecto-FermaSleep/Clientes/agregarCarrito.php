<?php
isset($_GET['id']);
session_start();
$id = $_GET['id'];
$pedido = array();
$ruta = $_SESSION['usuario']."_Pedidos.json";
$descuento = 0;

    $conexion = mysqli_connect("localhost","root","") or die ("Fallo en la conexion");
	mysqli_select_db($conexion, "fermasleep") or die ("Error en la seleccion de la base de datos");

    $consulta = mysqli_query($conexion, "SELECT * FROM `productos` WHERE `id` = '$id'");

    while($row = mysqli_fetch_array($consulta)){
        $nombre = $row['nombre'];
        $precio = $row['precio'];
        $descuento = $row['descuento'];
        $color = $row['color'];
        $talla = $row['talla'];
        $descripcion = $row['descripcion'];
    }

if(file_exists($ruta)){
    //Leer Archivo       

    $archivo = file_get_contents($ruta);
    $pedido =  json_decode($archivo, true);

    $pedido[] = array('id' => $id);

    $json_string = json_encode($pedido);
    //echo $json_string;	

    $file = $ruta;
    file_put_contents($file, $json_string);
    echo '<META HTTP-EQUIV="REFRESH" CONTENT="0; URL=Productos.php">';

}else{
    $pedido[] = array('id' => $id);

    $json_string = json_encode($pedido);

    $file = $ruta;
    file_put_contents($file, $json_string);

    echo '<META HTTP-EQUIV="REFRESH" CONTENT="0; URL=Productos.php">';
}
?>