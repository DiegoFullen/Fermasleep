function envia(){
    fetch('../CrearPdf.php')
}