<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style-Carrito.css">
    
    <title>Carrito</title>
</head>
<body>
    <section class="top-section">
        <div>
            <img src="../images/logo-mini_1.3.png" alt="logo.FERMASLEEP" class="logo">
        </div>
        <div class="semiNav2">
        </div>
    </section>
    <nav class="navegador">
        <ul class="semiNav">
            <li class="bloqueNav">
                <a href="menuClientes.php" class="txtNav"><img src="../images/iconos/banner/home.png" alt=""  width="20" height="20" class="icon-banner">Home</a>
            </li>
            <li class="bloqueNav">
                <a href="Productos.php" class="txtNav"><img src="../images/iconos/banner/shop.png" alt="" width="20" height="20" class="icon-banner">Productos</a>
            </li>
            <li class="bloqueNav">
                <a href="../Ubicacion.html" class="txtNav"><img src="../images/iconos/banner/ubicacion.png" alt="" width="20" height="20" class="icon-banner">Ubicacion</a>
            </li>
        </ul>
    </nav>      
    <section class="seccion3">
        <table class="tablaProductos">
            <?php
            session_start();
            $NombreArchivo = $_SESSION['usuario']."_Pedidos.json";
                $Total = 0;
                $Descuento = 0;
                $Cargos = 0;
                if(file_exists($NombreArchivo)){
                    $conexion = mysqli_connect("localhost","root","") or die ("Fallo en la conexion");
                    mysqli_select_db($conexion, "fermasleep") or die ("Error en la seleccion de la base de datos");

                    $archivo = file_get_contents($NombreArchivo);
					$productos = json_decode($archivo);
                    foreach($productos as $producto){
                        $id = $producto->{'id'};
                        $query = mysqli_query($conexion, "SELECT * FROM `productos` WHERE `id` = '$id'");
                        while($row = mysqli_fetch_array($query)){
                            echo '
                            <tr style="width: 100%">
                            <td style="width: 100%">
                            <div class="elementosCarrito">
                            <div class="card-top">';
                            if($row['descuento'] != 0){
                                echo '<h5 class="card-top-text">PROMOCION</h5>';
                            }else{
                                echo '<h5 class="card-top-text"></h5>';
                            }
                            echo '<a href="eliminar.php?id='.$row['id'].'" class="iconDelete"><img src="../images/iconos/eliminar.png" alt="eliminar" width="40" height="40" "></a>
                            </div>
                            <div class="split">
                                <img src="../images/productos/pijama'.$row['id'].'.jpg" alt="logo.FERMASLEEP" class="card">
                                <div style="justify-content: left; display: flex; width: 60%;">
                                    <div style="margin-left: 40px; width: 70%;">
                                        <div class="detalles2">
                                            <h5>Precio</h5>
                                            <h5 style="color: rgb(0, 200, 200); font-weight: bold; font-size: 20px;">$'.$row['precio'].'</h5>
                                        </div>
                                        <div class="detalles2">
                                            <h5>Descuento</h5>
                                            <h5>'.$row['descuento'].'%</h5>
                                        </div>
                                        <div class="detalles2">
                                            <h5>Color</h5>
                                            <div class="cuadroColor" style="background-color: #'.$row['color'].';"></div>
                                        </div>
                                        <div class="detalles2">
                                            <h5>Talla</h5>
                                            <h5>'.$row['talla'].'</h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="details">
                                <h4 style="color: rgb(50, 50, 50); font-weight: bold; font-size: 26px;">'.$row['nombre'].'</h4>           
                                <div style="width: 100%; height: auto;">
                                    <p class="parrafos">'.$row['descripcion'].'</p>
                                </div>
                            </div>
                        </div>
                        </td></tr>';
                        $Total = $Total + $row['precio'];
                        $Descuento = $Descuento + ($row['precio'] * $row['descuento'])/100;
                        }
                    }
                    echo '</table>';
                    echo '<aside class="pago"">
                    <div>
                        <h4 style="font-weight: bold; font-size: 25px;">Detalle Total</h4>
                    </div>
                    <div class="desgloce-precios">
                        <div class="precios">
                            <h5>Sub Total</h5>
                            <h5>$ '.$Total.'</h5>
                        </div>
                        <div class="precios">
                            <h5>Descuento</h5>
                            <h5>$ '.$Descuento.'</h5>
                        </div>
                        <div class="precios">
                            <h5>Cargo Entrega</h5>
                            <h5>'.$Cargos.'</h5>
                        </div>
                    </div>
                    <div class="desgloce-precios" style="border: none;">
                        <div class="precioFinal">
                            <h5>Total:</h5>
                            <h5>'.(($Total- $Descuento) + $Cargos).'</h5>
                        </div>
                    </div>';
                    echo '
                        <div class="boton">
                            <button class="truck-button" id="boton" onclick="envia();">
                                <span class="default">Realizar Pago</span>
                                <span class="success">
                                    Enviado
                                <svg viewbox="0 0 12 10">
                                    <polyline points="1.5 6 4.5 9 10.5 1"></polyline>
                                </svg>
                                </span>
                            <div class="truck">
                                <div class="wheel"></div>
                                <div class="back"></div>
                                <div class="front"></div>
                                <div class="box"></div>
                            </div>
                            </button>
                        <script src="https://cdn.jsdelivr.net/npm/gsap@3.0.1/dist/gsap.min.js"></script><script  src="../animacion.js"></script>
                            </div>
                        ';
            }
        ?>
            <script src="evento.js"></script>
        </aside>
         
    </section>
</body>
<footer>
    <div class="footer-container">
        <div class="footer-socials">
            <a class="footer-solcials-link" href="#"><img src="../images/iconos/social/facebook.png" alt="facebook" class="icon"></a>
            <a class="footer-solcials-link" href="#"><img src="../images/iconos/social/instagram.png" alt="instagram" class="icon"></a>
            <a class="footer-solcials-link" href="#"><img src="../images/iconos/social/twitter.png" alt="twitter" class="icon"></a>
            <a class="footer-solcials-link" href="#"><img src="../images/iconos/social/pinterest.png" alt="pinterest" class="icon"></a>
        </div>
    </div>
</footer>
</html>