'use strict'

var alumno = "Daniel Galvez";
var alumno = ["Daniel Galvez", "Rosa Santana", "German Cruz", "Alonso Torres"];
var materias = new Array("Computacion Paralela", "Virtualizacion", "Tecnologia Emergente");
var registro = [1234045, 3247823, 28642332, 12321321];
