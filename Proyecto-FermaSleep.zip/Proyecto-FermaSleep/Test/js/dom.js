'use strict'

document.write("Hola mundo\n");

var parrafo = document.getElementById("parrafo1");
var flag = true;
function color(){
    if(flag){
        parrafo.style.color = "white";
        parrafo.style.backgroundColor = "black";
    }else{
        parrafo.style.color = "black";
        parrafo.style.backgroundColor = "red";
    }
    
}

//gnome