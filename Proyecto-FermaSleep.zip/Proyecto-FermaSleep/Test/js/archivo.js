'use strict'
//alert("Hola Mundo");
// let = variable temporal  -------  var = variable local
/*
var nombre = "Pepe";
var edad = 20;
var empleado = true;
var salario = 1500.05;
var num1 = 0, num2 = 0;

nombre = prompt("¿Como te llamas?");
edad = prompt("¿Cual es tu edad?");
empleado = prompt("¿Eres empleado?");
salario = prompt("¿Cuanto ganas?");

num1 = parseInt(prompt("Primer numero"));
num2 = parseInt(prompt("Segundo numero"));

console.log(nombre);
console.log(typeof nombre);
console.log(edad);
console.log(typeof edad);
console.log(empleado);
console.log(typeof empleado);
console.log(salario);
console.log(typeof salario);

console.log("La suma es:" + (num1 + num2));
*/

var nombre = "Rosa";
var edad = 20;

if(edad > 18){
    console.log(nombre, "Puedes ingresar al curso");
}else{
    console.log(nombre, "No puedes ingresar al curso");
}

//switch, alert, if, 

var opc = parseInt(prompt("Elige una opcion 1- Registrar 2-Buscar 3-Mostrar"));
switch(log){
    case 1:
        console.log("Registrar");
        break;
    case 2:
        console.log("Buscar");
        break;
    case 3:
        break;
}