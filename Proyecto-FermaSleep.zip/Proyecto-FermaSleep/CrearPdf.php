<?PHP
	session_start();
?>

<?php

    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

    require 'PHPMailer/Exception.php';
    require 'PHPMailer/PHPMailer.php';
    require 'PHPMailer/SMTP.php';


    require('fpdf/fpdf.php');
    $pdf = new FPDF('P', 'mm', 'A4');
    $pdf->AddPage();
    $ID = substr(md5(microtime()), 0, 10);

    //Agregar Fuentes
    $pdf->AddFont('Times', '');

    $usuario = $_SESSION["usuario"];
    $nombre = "";
    $correo = "";

    $conexion = mysqli_connect("127.0.0.1","root","") or die ("Error en la conexión con la base de datos");
    #Selección de la base de datos
    mysqli_select_db($conexion, "fermasleep") or die ("Error en la selección de la base de datos");
        
    #Consulta para obtener datos
    $Resultado = mysqli_query($conexion, "SELECT * FROM `usuarios` WHERE `nombre` = '".$usuario."';");
    while($row = mysqli_fetch_array($Resultado)){

            $nombre = $row['nombre'];
            $correo = $row['correo'];
    }

    /*
        $pdf->SetFillColor(10,10,101);
        $pdf->SetDrawColor(255,255,255);
        $pdf->SetTextColor(150,100,0);
    */

    $pdf->Image('images/MARCA.png', 20, 6, 30);
    $pdf->SetAutoPageBreak(true);

    $pdf->SetXY(10, 10);
    $pdf->SetFont('Times', '', 15);

    $pdf->Cell(50);
    $pdf->Cell(50, 10, utf8_decode('Tienda de pijamas ---- FERMASLEEP'), 0,0, 'L');
    $pdf->Ln(10);
    $pdf->Cell(50);
    $pdf->Cell(50, 10, utf8_decode('Pijamas de buena calidad a precios accesibles'), 0,0, 'L');
    $pdf->Ln(20);
    $pdf->Cell(8);

    $pdf->Cell(30, 10, utf8_decode('Número de Pedido: No. ').$ID, 0,0, 'L');
    $pdf->Cell(35);
    $pdf->Ln(15);
    $pdf->Cell(40, 10, utf8_decode('Comprado por: '.$nombre.''), 0,0, 'L');
    $pdf->Ln(15);
    $pdf->Cell(8);
    $pdf->Cell(0, 10, utf8_decode('Enviado a: '.$correo), 0,0, 'L');
    $pdf->Ln(15);
    $pdf->Cell(5);

    $pdf->MultiCell(0, 10, utf8_decode('Ve a cualquier sucursal OXXO y usa el ID para realizar la compra') , 0, 'C');
    $pdf->Ln(30);

    $pdf->SetFont('Times', '', 30);
    $pdf->MultiCell(0, 10, utf8_decode('ID: '. $ID) , 0, 'C');

    $pdf->SetFont('Times', '', 15);
    $pdf->Ln(55);
    $pdf->Cell(10);
    $pdf->Cell(0, 0, utf8_decode('Ticket para la compra de:'), 0,0, 'C');
    $pdf->Ln(6);
    $pdf->Cell(20);


        $pdf->Cell(10, 10, utf8_decode('Producto'), 0,0, 'C');
        $pdf->Cell(30);
        $pdf->Cell(50, 10, utf8_decode('Cantidad'), 0,0, 'C');
        $pdf->Cell(10);
        $pdf->Cell(8, 10, utf8_decode('Talla'), 0,0, 'C');
        $pdf->Cell(22);
        $pdf->Cell(10, 10, utf8_decode('Descuento'), 0,0, 'C');
        $pdf->Cell(20);
        $pdf->Cell(10, 10, utf8_decode('SubTotal'), 0,0, 'C');
        $pdf->Ln(15);
        $pdf->Cell(5);

        $NombreArchivo = "Clientes/".$usuario."_Pedidos.json";

        $Total = 0;
        $IVA = 0;

        $archivo = file_get_contents($NombreArchivo);
		$productos = json_decode($archivo);
        foreach($productos as $producto){
            $id = $producto->{'id'};
            $query = mysqli_query($conexion, "SELECT * FROM `productos` WHERE `id` = '$id'");
            while($row = mysqli_fetch_array($query)){
                    
                $pdf->Cell(40, 10, $row['nombre'], 0,0, 'C');
                $pdf->Cell(30);
                $pdf->Cell(20,10, "1", 0,0, 'C');
                $pdf->Cell(18);
                $pdf->Cell(20,10, $row['talla'], 0,0, 'C');
                $pdf->Cell(10);
                $pdf->Cell(20,10, $row['descuento'].'%', 0,0, 'C');
                $pdf->Cell(10);
                $pdf->Cell(24,10, '$'.$row['precio'].'', 0,0, 'C');

                $pdf->Ln(10);
                $pdf->Cell(5);
                $Total = $Total + intval($row['precio']);
            }

            
        }
        $IVA = $Total*0.16;

        $pdf->SetFont('Times', '', 20);

        $pdf->Ln(15);
        $pdf->Cell(100);
        $pdf->Cell(30, 10, 'Total a Pagar: $'. $Total.'', 0,0, 'R');
        $pdf->Ln(10);
        $pdf->Cell(108);
        $pdf->Cell(30, 10, 'Total (IVA): $'. $IVA, 0,0, 'R');
        $pdf->Ln(10);

        $pdf->SetFont('Times', '', 15);

    $pdf->Ln(20);
    $pdf->Cell(5);
    $pdf->Cell(0, 10, utf8_decode('Buscanos en Instagram y redes sociales como: @Ferma-mx') , 0,0, 'L');
    $pdf->Ln(10);
    $pdf->Cell(5);
    $pdf->Cell(0, 10, utf8_decode('O contactanos al 3311944073 para mas detalles') , 0,0, 'L');

    $pdf->Output('Clientes/Recibos/'.$usuario.'-'.$ID.'_pago.pdf', 'F');
    $pdf->Output($usuario.'-'.$ID.'_pago.pdf', 'I');
    unlink($NombreArchivo);


    $Mensaje = 'Complete su compra para que se envien las pijamas
    '."\n".'Agradecemos mucho la confianza con esta marca';
    $file = 'Clientes/Recibos/'.$usuario.'-'.$ID.'_pago.pdf';

    $mail = new PHPMailer(true);
    try {
        //Server settings
        $mail->SMTPDebug = 2;                      //Enable verbose debug output
        $mail->isSMTP();                                            //Send using SMTP
        $mail->Host       = 'smtp-mail.outlook.com';                     //Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
        $mail->Username   = 'dcandiafullen@outlook.com';                     //SMTP username
        $mail->Password   = 'salvador1110022';                               //SMTP password
        $mail->SMTPSecure = 'STARTTLS';            //Enable implicit TLS encryption
        $mail->Port = 587;
        $mail->SMTPOptions = array(
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            )
        );

        //Recipients
        $mail->setFrom('dcandiafullen@outlook.com', 'Tienda Fermasleep');
        $mail->addAddress($correo);     //Add a recipient

        //Attachments
        $mail->addAttachment($file, 'Ticket - '. $ID);         //Add attachments
    
        //Content
        $mail->isHTML(true);                                  //Set email format to HTML
        $mail->Subject = 'Ticket de Compra ('.$ID.') - FERMASLEEP';
        $mail->Body    = $Mensaje;
    
        $mail->send();

        echo 'El mensaje se ha mandado';
    } catch (Exception $e) {
        echo "El mensaje no se pudo mandar. Mailer Error: {$mail->ErrorInfo}";
    }
    
    mysqli_close($conexion);
?>