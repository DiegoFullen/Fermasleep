<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <script src="./enter.js"></script>
    <title>Productos</title>
</head>
<body class="cuerpo">
    <section class="top-section">
        <div>
            <img src="images/logo-mini_1.3.png" alt="logo.FERMASLEEP" class="logo">
        </div>
        <div class="semiNav2">
            <div class="bloqueNav2">
                <a href="Login.html" class="txtNav" style="font-weight: bold;"><img src="images/iconos/banner/login.png" alt="" width="20" height="20" class="icon-banner">Login</a>
            </div>
        </div>
    </section>
    <nav class="navegador">
        <ul class="semiNav">
            <li class="bloqueNav">
                <a href="index.html" class="txtNav"><img src="images/iconos/banner/home.png" alt=""  width="20" height="20" class="icon-banner">Home</a>
            </li>
            <li class="bloqueNav">
                <a href="Productos.php" class="txtNav"><img src="images/iconos/banner/shop.png" alt="" width="20" height="20" class="icon-banner">Productos</a>
            </li>
            <li class="bloqueNav">
                <a href="Ubicacion.html" class="txtNav"><img src="images/iconos/banner/ubicacion.png" alt="" width="20" height="20" class="icon-banner">Ubicacion</a>
            </li>
        </ul>
    </nav>
    <!-- 
    <div class="navBusqueda">
        <img src="images/iconos/buscar.png" alt="" height="45px" width="45px" class="iconBuscar">
        <input type="text" class="textoBuscar" id="txtBusca" placeholder="Buscar un producto">
    </div>
    -->
    <section class="seccion2">
        <table class="tablaProductos"> 
            <tr class="trProductos">
                <?php
		            $conexion = mysqli_connect("localhost","root","")
		            or die ("Fallo en la conexion");

		            mysqli_select_db($conexion, "fermasleep")
		            or die ("Error en la seleccion de la base de datos");

		            $Resultado = mysqli_query($conexion,"SELECT * FROM `productos`;");

		                while ($row = mysqli_fetch_array($Resultado)) {
                            echo '
                            <td class="tdProductos">
                                <div class="elementos">
                                    <div class="card-top">';
                                    if($row['descuento'] != 0){
                                        echo '<h3 class="card-top-text">PROMOCION</h3>';
                                        }else{
                                        echo '<h3 class="card-top-text"> </h3>';
                                    }
                                    echo '
                                    </div>
                                    <img src="images/productos/pijama'.$row['id'].'.jpg" alt="logo.FERMASLEEP" class="card">
                                    <div class="details">
                                        <h4 style="color: rgb(50, 50, 50); font-weight: bold;">'.$row['nombre'].'</h4>
                                        <div style="width: 100%; height: auto;">
                                            <p class="parrafos">'.$row['descripcion'].'</p>
                                        </div>';
                                        echo '
                                        <div class="card-price">
                                            <h5 class="price">$'.$row['precio']-(($row['descuento']*$row['precio'])/100).'</h5>';
                                            if ($row['descuento'] != 0){
                                                echo '<h5 class="discount-price">$'.$row['precio'].'</h5>';
                                            }
                                        echo'    
                                        </div>
                                    </div>
                                    <div class="cardDetails">
                                        <a href="agregarCarrito.php?id='.$row['id'].'"><img src="images/iconos/card/carrito.png" alt="carrito" class="iconCard" width="40" height="40"></a>
                                        <a href="#"><img src="images/iconos/card/fav.png" alt="favorite" class="iconCard" width="40" height="40"></a>
                                        <a href="#"><img src="images/iconos/card/ver.png" alt="see" class="iconCard" width="40" height="40"></a>
                                    </div>
                                </div>
                            </td>';
                            if(($row['id']%3) == 0){
                                echo '<tr>';                                                                                                                                         
                            }
		                }	
		            mysqli_close($conexion);
		        ?>
            </tr>
        </table>
    </section>
</body>
<footer>
    <div class="footer-container">
        <div class="footer-socials">
            <a class="footer-solcials-link" href="#"><img src="./images/iconos/social/facebook.png" alt="facebook" class="icon"></a>
            <a class="footer-solcials-link" href="#"><img src="./images/iconos/social/instagram.png" alt="instagram" class="icon"></a>
            <a class="footer-solcials-link" href="#"><img src="./images/iconos/social/twitter.png" alt="twitter" class="icon"></a>
            <a class="footer-solcials-link" href="#"><img src="./images/iconos/social/pinterest.png" alt="pinterest" class="icon"></a>
        </div>
    </div>
</footer>
</html>