<?php
    include 'conexion.php';
    
    $Nombre = $_POST['nombre'];
    $Apellido = $_POST['apellido'];
    $pwd = $_POST['pwd'];
    $edad = $_POST['edad'];
    $telefono = $_POST['telefono'];
    $correo = $_POST['correo'];

    $sql = mysqli_query($con, "INSERT INTO `usuarios` (`id`, `nombre`, `contrasena`, `edad`, `telefono`, `correo`, `apellido`) VALUES ('0', '$Nombre', '$pwd', '$edad', '$telefono', '$correo', '$Apellido');");

    if($sql){
        echo "Registro exitoso";
        header("location:Login.html");
    }else{
        echo "fallo el registro ";
    }
?>