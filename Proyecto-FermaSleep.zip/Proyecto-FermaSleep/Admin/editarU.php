<?php
        isset($_POST['id']);
        $id = $_POST['id'];
		$nombre = $_POST['nombre'];
        $apellido = $_POST['apellido'];
        $edad = $_POST['edad'];
        $correo = $_POST['correo'];
        $pwd = $_POST['pwd'];
        $telefono = $_POST['telefono'];


        $conexion = mysqli_connect("localhost","root","")
		or die ("Fallo en la conexion");

		mysqli_select_db($conexion, "fermasleep") or die ("Error en la seleccion de la base de datos");

		$query = mysqli_query($conexion,"UPDATE `usuarios` SET `nombre`='$nombre',
        `contrasena`='$pwd',`edad`='$edad',`telefono`='$telefono',`correo`='$correo',
        `apellido`='$apellido' WHERE `id`='$id'");

        echo '<META HTTP-EQUIV="REFRESH" CONTENT="0; URL=Usuarios.php">';
	?>