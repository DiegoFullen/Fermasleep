<?php
        isset($_POST['id']);
        $id = $_POST['id'];
		$nombre = $_POST['nombre'];
        $precio = $_POST['precio'];
        $descuento = $_POST['descuento'];
        $stock = $_POST['stock'];
        isset($_POST['descripcion']);
        $descripcion = $_POST['descripcion'];

        $talla = $_POST['talla'];
        $color = $_POST['color'];


        $conexion = mysqli_connect("localhost","root","")
		or die ("Fallo en la conexion");

		mysqli_select_db($conexion, "fermasleep") or die ("Error en la seleccion de la base de datos");

		$query = mysqli_query($conexion,"UPDATE `productos` SET `nombre`='$nombre',
        `precio`='$precio',`descuento`='$descuento',`stock`='$stock',`descripcion`='$descripcion',
        `talla`='$talla', `color`='$color' WHERE `id`='$id'");

        echo '<META HTTP-EQUIV="REFRESH" CONTENT="0; URL=Productos.php">';
	?>