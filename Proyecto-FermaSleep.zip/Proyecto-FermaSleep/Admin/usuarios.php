<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style-Usuarios.css">
    <title>FERMASLEEP</title>
</head>
<body>
<section class="top-section">
        <div>
            <img src="../images/logo-mini_1.3.png" alt="logo.FERMASLEEP" class="logo">
        </div>
        <div class="semiNav2">
            <div class="bloqueNav2" style="width: fit-content;">
                <a href="usuarios.php" class="txtNav" style="font-weight: bold; "><img src="../images/iconos/banner/login.png" alt="" width="20" height="20" class="icon-banner">Administar Usuarios</a>
            </div>
        </div>
    </section>
    <nav class="navegador">
        <ul class="semiNav">
            <li class="bloqueNav">
                <a href="menuAdmin.php" class="txtNav"><img src="../images/iconos/banner/home.png" alt=""  width="20" height="20" class="icon-banner">Home</a>
            </li>
            <li class="bloqueNav">
                <a href="Productos.php" class="txtNav"><img src="../images/iconos/banner/shop.png" alt="" width="20" height="20" class="icon-banner">Productos</a>
            </li>
            <li class="bloqueNav">
                <a href="../Ubicacion.html" class="txtNav"><img src="../images/iconos/banner/ubicacion.png" alt="" width="20" height="20" class="icon-banner">Ubicacion</a>
            </li>
        </ul>
    </nav>
      
    <section class="seccion1">
        <div class="Formulario">
            <form method="POST" action="#" name="FormRegistro" class="Form1"> 
                <h2>Añadir usuario</h2>
                <div class="columna">
                    <label> Nombre</label>
                    <input type="text" placeholder="Nombre" id="nombre" name="nombre">
                    <label> Apellido</label>
                    <input type="text" placeholder="Apellido" id="apellido" name="apellido">
                </div>
                <div class="columna">
                    <label> Correo Electronico</label>
                    <input type="text" placeholder="Correo Electronico" id="correo" name="correo">
                    <label> Contraseña</label>
                    <input type="password" placeholder="Contraseña" id="pwd" name="pwd">
                </div>
                <div class="columna">
                    <label> Edad</label>
                    <input type="text" placeholder="Edad" id="edad" name="edad">
                    <label> Telefono</label>
                    <input type="text" placeholder="felefono" id="telefono" name="telefono">
                </div>
                <button type="submit" name="enviar" class="btnRegistar">Registrar</button>
            </form>
        </div>
    </section>
    <section>
        <h2>Administar Usuarios</h2>
        <table class="tablaProductos">
            <tr class="trProductos">
            <?php
		            $conexion = mysqli_connect("localhost","root","")
		            or die ("Fallo en la conexion");

		            mysqli_select_db($conexion, "fermasleep")
		            or die ("Error en la seleccion de la base de datos");

		            $Resultado = mysqli_query($conexion,"SELECT * FROM `usuarios`;");

		                while ($row = mysqli_fetch_array($Resultado)) {
                            echo '
                            <tr style="width: 100%">
                            <td style="width: 100%">
                            <div class="elementosCarrito">
                            <div class="card-top">
                                <a href="eliminarUsuarios.php?id='.$row['id'].'" class="iconDelete"><img src="../images/iconos/eliminar.png" alt="eliminar" width="40" height="40" "></a>
                                <a href="editarUsuarios.php?id='.$row['id'].'" class="iconEdit"><img src="../images/iconos/editar.png" alt="eliminar" width="40" height="40" "></a>
                            </div>
                            
                            <div class="split">
                                <img src="../images/iconos/'.$row['tipo'].'.png" alt="user" class="card">
                                <div style="justify-content: left; display: flex; width: 80%;">
                                    <div style="margin-left: 40px; width: 70%;">
                                        <div class="detalles2">
                                            <h5>Edad</h5>
                                            <h5>'.$row['edad'].' años</h5>
                                        </div>
                                        <div class="detalles2">
                                            <h5>telefono</h5>
                                            <h5>'.$row['telefono'].'</h5>
                                        </div>
                                        <div class="detalles2">
                                            <h5>Correo</h5>
                                            <h5>Correo'.$row['correo'].'</h5>
                                        </div>
                                        <div class="detalles2">
                                            <h5>id</h5>
                                            <h5>'.$row['id'].'</h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="details">
                                <h4 style="color: rgb(50, 50, 50); font-weight: bold; font-size: 20px;">Nombre: '.$row['nombre'].'</h4>
                                <h4 style="color: rgb(50, 50, 50); font-weight: bold; font-size: 20px;">Apellido: '.$row['apellido'].'</h4>
                            </div>
                        </div>
                        </td></tr>';
                            if(($row['id']%3) == 0){
                                echo '<tr>';                                                                                                                                         
                            }
		                }	
		            mysqli_close($conexion);
		        ?>
            </tr>
        </table>
    </section>
</body>
</html>