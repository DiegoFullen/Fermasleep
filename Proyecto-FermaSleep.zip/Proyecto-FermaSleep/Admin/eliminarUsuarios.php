<?php
        isset($_GET['id']);
        $id = $_GET['id'];
		
        $conexion = mysqli_connect("localhost","root","")
		or die ("Fallo en la conexion");

		mysqli_select_db($conexion, "fermasleep") or die ("Error en la seleccion de la base de datos");

		$query = mysqli_query($conexion,"DELETE FROM `usuarios` WHERE `id` = $id");

        echo '<META HTTP-EQUIV="REFRESH" CONTENT="0; URL=Usuarios.php">';
	?>