<?php
    $conexion = mysqli_connect("localhost","root","")
    or die ("Fallo en la conexion");

mysqli_select_db($conexion, "fermasleep")
    or die ("Error en la seleccion de la base de datos");
    
    $Nombre = $_POST['nombre'];
    $Precio = $_POST['precio'];
    $Descuento = $_POST['descuento'];
    $Stock = $_POST['stock'];
    $Descripcion = $_POST['descripcion'];
    $Color = $_POST['color'];
    $Talla = $_POST['talla'];

    $sql = mysqli_query($conexion, "INSERT INTO `productos` (`id`, `nombre`, `precio`, `descuento`, `stock`, `descripcion`, `color`, `talla`) 
    VALUES ('0', '$Nombre', '$Precio', '$Descuento', '$Stock', '$Descripcion', '$Color', '$Talla');");

    if($sql){
        echo "Registro exitoso";
        header("location:Productos.php");
    }else{
        echo "fallo el registro ";
    }
?>