<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style-Usuarios.css">
    <title>FERMASLEEP</title>
</head>
<body>
<section class="top-section">
        <div>
            <img src="../images/logo-mini_1.3.png" alt="logo.FERMASLEEP" class="logo">
        </div>
        <div class="semiNav2">
            <div class="bloqueNav2" style="width: fit-content;">
                <a href="usuarios.php" class="txtNav" style="font-weight: bold; "><img src="../images/iconos/banner/login.png" alt="" width="20" height="20" class="icon-banner">Administar Usuarios</a>
            </div>
        </div>
    </section>
    <nav class="navegador">
        <ul class="semiNav">
            <li class="bloqueNav">
                <a href="menuAdmin.php" class="txtNav"><img src="../images/iconos/banner/home.png" alt=""  width="20" height="20" class="icon-banner">Home</a>
            </li>
            <li class="bloqueNav">
                <a href="Productos.php" class="txtNav"><img src="../images/iconos/banner/shop.png" alt="" width="20" height="20" class="icon-banner">Productos</a>
            </li>
            <li class="bloqueNav">
                <a href="../Ubicacion.html" class="txtNav"><img src="../images/iconos/banner/ubicacion.png" alt="" width="20" height="20" class="icon-banner">Ubicacion</a>
            </li>
        </ul>
    </nav>
<?php
    isset($_GET['id']);
    $ID = $_GET['id'];

    $conexion = mysqli_connect("localhost","root","")
	    or die ("Fallo en la conexion");

	mysqli_select_db($conexion, "fermasleep")
	    or die ("Error en la seleccion de la base de datos");

	$Resultado = mysqli_query($conexion,"SELECT * FROM `productos` WHERE `id` = '$ID'");

        while ($row = mysqli_fetch_array($Resultado)) {
        echo '
        <section class="seccion1">
        <div class="Formulario">
            <form method="POST" action="editarP.php" name="FormRegistro" class="Form1"> 
                <h2>Editar producto</h2>
                <div class="columna">
                    <label> ID</label>
                    <input type="text" readonly="readonly" id="id" name="id" value="'.$ID.'">
               
                </div>
                <div class="columna">
                    <label> Nombre</label>
                    <input type="text" placeholder="Nombre" id="nombre" name="nombre" value="'.$row['nombre'].'">
                    <label> Precio</label>
                    <input type="number" placeholder="Precio" id="precio" name="precio" value="'.$row['precio'].'">
                </div>
                <div class="columna">
                    <label> Descuento</label>
                    <input type="number" placeholder="Descuento" id="descuento" name="descuento" value="'.$row['descuento'].'">
                    <label> Stock</label>
                    <input type="number" placeholder="Stock" id="stock" name="stock" value="'.$row['stock'].'">
                </div>
                <div class="columna">
                    <label> Descripcion</label>
                    <textarea type="text" placeholder="Descripcion" id="descripcion" name="descripcion" cols="50" rows="6">'.$row['descripcion'].'</textarea>
                    <label> Talla</label>
                    <input type="text" placeholder="Talla" id="talla" name="talla" value="'.$row['talla'].'">
                </div>
                <div class="columna">
                    <label> Color (Hexadecimal, #000000)</label>
                    <input type="text" placeholder="Color" id="color" name="color" value="'.$row['color'].'">
                    <input type="color">
                </div>
                <button type="submit" name="enviar" class="btnRegistar">Editar</button>
            </form>
        </div>
    </section>';
    }
	mysqli_close($conexion);
	?>
    </tr>
        </table>
    </section>
</body>
</html>